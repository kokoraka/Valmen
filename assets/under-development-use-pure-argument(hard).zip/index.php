<!DOCTYPE html>
<!--
  Nah, tired doing all this stuff by myself.
  ~Raka
-->
<html>
<head>
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css" />
  <style>
    .row {
      margin-top:2px;
      margin-bottom:2px;
    }
  </style>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Kelompok 1 (RIP) | Validitas Argumen - Matematika Diskrit 7</title>
</head>
<body>
  <?php include_once("functions.php"); ?>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 style="text-align:center;">Kelompok 1 (RIP)</h1>
        <p style="text-align:center;">Validitas Argumen</p>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <p style="text-align:center;">Aplikasi ini dibuat untuk memenuhi tugas mata kuliah <b>Matematika Diskrit 7</b>.</p>
      </div>
    </div>
    <div class="row">
      <div class="col-md-8 col-md-offset-2">
        <hr />
        <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
          <div class="form-group">
            <div class="row">
              <div class="col-md-12">
                <label for="input-premis-1">Argumen:</label>
                <textarea id="input-premis-1" name="input-premis-1" class="form-control" rows="5" cols="" placeholder="Tulis argumen.."><?php if (compare($_SERVER["REQUEST_METHOD"], "POST", "L")) { echo $_POST["input-premis-1"]; } ?></textarea>
              </div>
            </div>
          </div>
          <!--
          <div class="form-group">
            <select class="form-control">
              <option>Negasi (&not;)</option>
              <option>Konjungsi (&and;)</option>
              <option>Disjungsi (&or;)</option>
              <option>Disjungsi Eksklusif (&oplus;)</option>
              <option>Implikasi (&rarr;)</option>
              <option>Bi-implikasi (&harr;)</option>
            </select>
          </div>
          -->
          <div class="form-group">
            <button type="submit" class="btn btn-md btn-default btn-block">Periksa Argumen</button>
          </div>
        </form>
      </div>
    </div>

    <div class="row">
      <div class="col-md-8 col-md-offset-2">
        <hr />
        <?php if (compare($_SERVER["REQUEST_METHOD"], "POST", "L")) { ?>
          <div class="row">
            <div class="col-md-12"><h4 style="text-align:center;">Hasil Pengolahan</h4></div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <b>Argumen:</b>
              <br />
              <?php $data = destroy_empty_array(explode(".", $_POST["input-premis-1"])); ?>
              <?php show_argument($data); ?>
            </div>
            <div class="col-md-6">
              <b>Proposisi:</b>
              <br />
              <?php show_proposition($data); ?>
            </div>
          </div>
          <div class="row">
            <div class="col-md-6">
              <b>Variabel:</b>
              <br />
              <?php $var = get_all_variable($data, $exp); show_variable($var, $vnm); ?>
            </div>
            <div class="col-md-6">
              <b>Formulasi:</b>
              <br />
              <?php show_formulation($data, $var, $exp, $vnm); ?>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12"><h4 style="text-align:center;">Tabel Kebenaran</h4></div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="table-responsive">
                <table class="table table-bordered">
                  <tr>
                    <th>AA</th>
                    <th>BB</th>
                  </tr>
                  <tr>
                    <td>Content - 1</td>
                    <td>Content - 2</td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12"><h4 style="text-align:center;">Kesimpulan</h4></div>
          </div>
          <div class="row">
            <div class="col-md-12">
              Setelah dilakukan pengolahan dan analisis informasi, aplikasi mendeteksi bahwasanya argumen: <br />
              <blockquote style="font-size:11pt; margin-top:2px; margin-bottom:2px; font-style:italic;">
                <?php show_argument($data); ?>
              </blockquote>
              merupakan argumen yang <?php echo argument_conclusion(true); ?>.
            </div>
          </div>
        <?php } else { ?>
          <div class="row">
            <div class="col-md-6"><b>Petunjuk & Catatan Penggunaan:</b></div>
            <div class="col-md-6"><b>Contoh Argumen:</b></div>
          </div>
          <div class="row" style="margin-top:5px;">
            <div class="col-md-6">
              <ul type="square">
                <li>Pisahkan proposisi dengan tanda baca titik.</li>
                <li>Proposisi 1..(n-1) diasumsikan sebagai premis.</li>
                <li>Proposisi n diasumsikan sebagai konklusi.</li>
                <li>Hanya mendukung penggunaan berbahasa Indonesia.</li>
                <li>Penulisan proposisi harus sesuai antar variabel satu dengan lainnya (makan &ne; mkn)</li>
              </ul>
            </div>
            <div class="col-md-6">
              <blockquote style="font-size:11pt;">
                Jika saya makan maka saya kenyang.<br />
                Saya makan.<br />
                Saya kenyang.
              </blockquote>
            </div>
          </div>
        <?php } ?>
        <hr />
      </div>
    </div>

    <div class="row">
      <div class="col-md-12">
        <p style="text-align:center;"><b style="font-size:14pt;">R</b>aka (10115253), <b style="font-size:14pt;">I</b>khsan (10115220), <b style="font-size:14pt;">P</b>aulus (10112781)</p>
        <p style="text-align:center;">Copyright &copy; 2017 Kelompok 1 (RIP) All Rights Reserved</p>
        <p style="text-align:center;">Universitas Komputer Indonesia</p>
      </div>
    </div>
  </div>
  <script type="text/javascript" href="assets/bootstrap/js/bootstrap.js"></script>
</body>
</html>
