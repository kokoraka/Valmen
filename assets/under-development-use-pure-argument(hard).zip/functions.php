<?php
  /* library */
  $exp = array(
    "negation"=>array(
      "bukan","tidak"
    ),
    "conjunction"=>array(
      "dan"
    ),
    "disjunction"=>array(
      "atau"
    ),
    "conditional"=>array(
      "jika","maka",",","mengakibatkan","hanya jika","syarat cukup","syarat perlu","bilamana"
    ),
    "biconditional"=>array(
      "jika","maka",",","dan jika","jika dan hanya jika","jika hanya jika","syarat perlu dan cukup","sebaliknya"
    )
  );

  $vnm = range('a', 'z');

  /* function */
  function textarea_to_string($data) {
    return ereg_replace("\n", "<br />", $data);
  }

  function destroy_empty_array($data) {
    foreach ($data as $key => $value) {
      $data[$key] = preg_replace( "/\r|\n/", "", $data[$key]);
      if (empty($value) || !isset($value) || $value == "" || $value == null || strlen($data[$key]) == 0) {
        unset($data[$key]);
      }
    }
    return $data;
  }

  function lowercase_array($data) {
    foreach ($data as $key => $value) {
      $data[$key] = strtolower($data[$key]);
    }
    return $data;
  }

  function ucfirst_array($data) {
    foreach ($data as $key => $value) {
      $data[$key] = ucfirst($data[$key]);
    }
    return $data;
  }

  function lrtrim($data) {
    return rtrim(ltrim($data, " "), " ");
  }
  function compare($a, $b, $lvl) {
    $res = ($a == $b);
    if ($lvl == "H") {
      $res = ($a === $b);
    }
    return $res;
  }

  function check_proposition($data, $exp, $op) {
    $res = 0;
    $data = explode(" ", strtolower($data));
    foreach ($data as $key => $value) {
      for ($i = 0; $i < count($exp[$op]); $i++) {
        if ($data[$key] == $exp[$op][$i]) {
          $res++;
        }
      }
    }
    return $res;
  }

  function get_variable($src, $op) {
    $res = array();
    $data = explode(" ", strtolower($src));
    switch ($op) {
      case 'conditional':
        if ($data[0] == "jika") {
          $a = ""; $b = ""; $x = 0;
          for ($i = 1; $i < count($data)-1; $i++) {
            if ($data[$i] == "maka") {
              $x = $i;
              break;
            }
            $a = $a . $data[$i] . " ";
          }
          for ($i = $x+1; $i < count($data); $i++) {
            $b = $b . $data[$i] . " ";
          }
          array_push($res, $a, $b);
        }
        else {
          //bentuk lain
        }
      break;
      case 'biconditional':

      break;
      case 'conjunction':
        $a = ""; $b = ""; $x = 0;
        for ($i = 0; $i < count($data); $i++) {
          if ($data[$i] == "dan") {
            $x = $i;
            break;
          }
          $a = $a . $data[$i] . " ";
        }
        for ($i = $x+1; $i < count($data); $i++) {
          $b = $b . $data[$i] . " ";
        }
        array_push($res, $a, $b);
      break;
      case 'disjunction':
        $a = ""; $b = ""; $x = 0;
        for ($i = 0; $i < count($data); $i++) {
          if ($data[$i] == "atau") {
            $x = $i;
            break;
          }
          $a = $a . $data[$i] . " ";
        }
        for ($i = $x+1; $i < count($data); $i++) {
          $b = $b . $data[$i] . " ";
        }
        array_push($res, $a, $b);
      break;
      case 'negation':
        $a = ""; $b = ""; $x = 0;
        for ($i = 0; $i < count($data); $i++) {
          if ($data[$i] == "bukan" || $data[$i] == "tidak") {
            $x = $i;
          }
          else {
            $a = $a . $data[$i] . " ";
          }          
        }
        array_push($res, $a);
      break;
      default: $res = strtolower($src); break;
    }
    return $res;
  }

  function get_all_variable($data, $exp) {
    $var = array();
    foreach ($data as $key => $value) {
      if (check_proposition($data[$key], $exp, "conditional") >= 1) {
        $tmp = get_variable($data[$key], "conditional");
        foreach ($tmp as $key => $value) {
          array_push($var, lrtrim($tmp[$key]));
        }
      }
      else if (check_proposition($data[$key], $exp, "biconditional") >= 2) {
        $tmp = get_variable($data[$key], "biconditional");
        foreach ($tmp as $key => $value) {
          array_push($var, lrtrim($tmp[$key]));
        }
      }
      else {
        if (check_proposition($data[$key], $exp, "conjunction") >= 1) {
          $tmp = get_variable($data[$key], "conjunction");
          foreach ($tmp as $key => $value) {
            array_push($var, lrtrim($tmp[$key]));
          }
        }
        else if (check_proposition($data[$key], $exp, "disjunction") >= 1) {
          $tmp = get_variable($data[$key], "disjunction");
          foreach ($tmp as $key => $value) {
            array_push($var, lrtrim($tmp[$key]));
          }
        }
        else if (check_proposition($data[$key], $exp, "negation") >= 1) {
          $tmp = get_variable($data[$key], "negation");
          foreach ($tmp as $key => $value) {
            array_push($var, lrtrim($tmp[$key]));
          }
        }
        else {
          array_push($var, get_variable(lrtrim($data[$key]), ""));
        }
      }
    }
    return array_unique($var);
  }

  function show_variable($var, $vnm) {
    foreach ($var as $key => $value) {
      echo $vnm[$key] . " = " . ucfirst($value) . "<br />";
    }
  }

  function show_argument($data) {
    for ($i = 0; $i < count($data); $i++) {
      echo $data[$i] . ".<br />";
    }
  }

  function show_proposition($data) {
    for ($i = 0; $i < count($data); $i++) {
      if ($i+1 == count($data)) {
        echo "<i>q</i>";
      }
      else {
        echo "<i>p" . ($i+1) . "</i>";
      }
      echo " = " . $data[$i] . "<br />";
    }
  }

  function show_formulation($data, $var, $exp, $vnm) {
    $i = 0;
    $frm = array();
    foreach ($data as $key => $value) {
      if ($i+1 == count($data)) {
        echo "<hr style='margin-top:1px; margin-bottom:1px;' /><b style='font-size:14pt;'>&there4;</b> ";
      }
      $i++;

      if (check_proposition($data[$key], $exp, "conditional") >= 1) {
        $tmp = get_variable($data[$key], "conditional");
        $fcon = "";
        foreach ($tmp as $k2 => $v2) {
          foreach ($var as $k1 => $v1) {
            $v2 = lrtrim($v2);
            if ($v1 == $v2) {
              $fcon = $fcon . $vnm[$k1];
            }
          }
          echo $fcon;
        }
      }
      else if (check_proposition($data[$key], $exp, "biconditional") >= 2) {
        $tmp = get_variable($data[$key], "biconditional");
        foreach ($tmp as $key => $value) {
          array_push($frm, lrtrim($tmp[$key]));
        }
      }
      else {
        if (check_proposition($data[$key], $exp, "conjunction") >= 1) {
          $tmp = get_variable($data[$key], "conjunction");
          foreach ($tmp as $key => $value) {
            array_push($frm, lrtrim($tmp[$key]));
          }
        }
        else if (check_proposition($data[$key], $exp, "disjunction") >= 1) {
          $tmp = get_variable($data[$key], "disjunction");
          foreach ($tmp as $key => $value) {
            array_push($frm, lrtrim($tmp[$key]));
          }
        }
        else if (check_proposition($data[$key], $exp, "negation") >= 1) {
          $tmp = get_variable($data[$key], "negation");
          foreach ($tmp as $key => $value) {
            array_push($frm, lrtrim($tmp[$key]));
          }
        }
        else {
          $tmp = lrtrim(get_variable($data[$key], ""));
          foreach ($var as $key => $value) {
            if ($tmp == $var[$key]) {
              echo $vnm[$key];
              break;
            }
          }
        }
      }
      echo "<br />";
    }
  }

  function argument_conclusion($data) {
    $res = '<strike>sahih(<i>valid</i>)</strike>/<b style="font-size:14pt;">palsu(<i>invalid</i>)</b>';
    if ($data) {
      $res = '<b style="font-size:14pt;">sahih(<i>valid</i>)</b>/<strike>palsu(<i>invalid</i>)</strike>';
    }
    return $res;
  }
?>
